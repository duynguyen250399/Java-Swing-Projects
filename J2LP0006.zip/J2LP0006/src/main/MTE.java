package main;

import com.ozten.font.JFontChooser;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Nguyen Khanh Duy
 */
public class MTE extends javax.swing.JFrame implements Runnable {

    private final long STACK_DELAY = 500; // in ms

    private String buffer;
    private boolean cutting;
    private Stack<String> undoStack;
    private Stack<String> redoStack;

    private Thread stackThread;

    private File openingFile;
    private JFileChooser fileChooser;

    public MTE() {
        initComponents();
        setTitle("My Text Editor");
        setLocationRelativeTo(null);
        this.txt.setFont(new Font("Tahoma", Font.PLAIN, 12));
        this.buffer = "";
        this.cutting = false;

        fileChooser = new JFileChooser();
        fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Text Documents (*.txt)", "txt"));
        fileChooser.setAcceptAllFileFilterUsed(true);

        this.undoStack = new Stack<>();
        this.redoStack = new Stack<>();

        this.stackThread = new Thread(this, "Auto Stack Thread");
        this.stackThread.start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txt = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menuNew = new javax.swing.JMenuItem();
        menuOpen = new javax.swing.JMenuItem();
        menuSave = new javax.swing.JMenuItem();
        menuSaveAs = new javax.swing.JMenuItem();
        menuExit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        menuSelectAll = new javax.swing.JMenuItem();
        menuCut = new javax.swing.JMenuItem();
        menuCopy = new javax.swing.JMenuItem();
        menuPaste = new javax.swing.JMenuItem();
        menuUndo = new javax.swing.JMenuItem();
        menuRedo = new javax.swing.JMenuItem();
        menuFind = new javax.swing.JMenuItem();
        menuReplace = new javax.swing.JMenuItem();
        menuChangeFont = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txt.setColumns(20);
        txt.setRows(5);
        jScrollPane1.setViewportView(txt);

        jMenu1.setText("File");

        menuNew.setText("New");
        menuNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuNewActionPerformed(evt);
            }
        });
        jMenu1.add(menuNew);

        menuOpen.setText("Open");
        menuOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuOpenActionPerformed(evt);
            }
        });
        jMenu1.add(menuOpen);

        menuSave.setText("Save");
        menuSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSaveActionPerformed(evt);
            }
        });
        jMenu1.add(menuSave);

        menuSaveAs.setText("Save as...");
        menuSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSaveAsActionPerformed(evt);
            }
        });
        jMenu1.add(menuSaveAs);

        menuExit.setText("Exit");
        menuExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuExitActionPerformed(evt);
            }
        });
        jMenu1.add(menuExit);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");

        menuSelectAll.setText("Select All");
        menuSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSelectAllActionPerformed(evt);
            }
        });
        jMenu2.add(menuSelectAll);

        menuCut.setText("Cut");
        menuCut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCutActionPerformed(evt);
            }
        });
        jMenu2.add(menuCut);

        menuCopy.setText("Copy");
        menuCopy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCopyActionPerformed(evt);
            }
        });
        jMenu2.add(menuCopy);

        menuPaste.setText("Paste");
        menuPaste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuPasteActionPerformed(evt);
            }
        });
        jMenu2.add(menuPaste);

        menuUndo.setText("Undo");
        menuUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuUndoActionPerformed(evt);
            }
        });
        jMenu2.add(menuUndo);

        menuRedo.setText("Redo");
        menuRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRedoActionPerformed(evt);
            }
        });
        jMenu2.add(menuRedo);

        menuFind.setText("Find");
        menuFind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFindActionPerformed(evt);
            }
        });
        jMenu2.add(menuFind);

        menuReplace.setText("Replace");
        menuReplace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuReplaceActionPerformed(evt);
            }
        });
        jMenu2.add(menuReplace);

        menuChangeFont.setText("Change font");
        menuChangeFont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuChangeFontActionPerformed(evt);
            }
        });
        jMenu2.add(menuChangeFont);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 807, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 476, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuOpenActionPerformed
        this.openingFile = getFile();
        if (this.openingFile != null) {
            try {
                readFile(this.openingFile);
                this.setTitle(this.openingFile.getName() + " - My Text Editor");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error when reading file!");
            }
        }
    }//GEN-LAST:event_menuOpenActionPerformed

    private File getFile() {
        File file = null;

        int choice = fileChooser.showOpenDialog(this);
        if (choice == JFileChooser.APPROVE_OPTION) {
            file = fileChooser.getSelectedFile();
        }

        return file;
    }

    private void readFile(File f) throws FileNotFoundException, IOException {
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);

        String line;
        StringBuilder fileContent = new StringBuilder();
        while ((line = br.readLine()) != null) {
            fileContent.append(line + "\n");
        }

        fr.close();
        br.close();

        this.txt.setText(fileContent.toString());

    }

    private void menuNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuNewActionPerformed
        
    }//GEN-LAST:event_menuNewActionPerformed

    private void menuSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSaveActionPerformed

        save();
    }//GEN-LAST:event_menuSaveActionPerformed

    private void save() {
        FileWriter fw = null;
        PrintWriter pw = null;

        File newFile = null;

        if (this.openingFile != null) {
            newFile = this.openingFile;
            try {
                fw = new FileWriter(openingFile);
                pw = new PrintWriter(fw);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error while saving file!");
            }

        } else {
            int choice = fileChooser.showSaveDialog(this);
            if (choice == JFileChooser.APPROVE_OPTION) {

                File f = fileChooser.getSelectedFile();
                newFile = new File(f.getAbsolutePath() + ".txt");

            }
        }

        try {
            if (newFile != null) {
                fw = new FileWriter(newFile);
                pw = new PrintWriter(fw);
                String fileContent = this.txt.getText();
                pw.write(fileContent);

                pw.close();
                fw.close();

                this.openingFile = newFile;
                this.setTitle(this.openingFile.getName() + " - My Text Editor");
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error while saving file!");
        }
    }

    private void saveAs() throws IOException {
        int choice = fileChooser.showSaveDialog(this);
        if (choice == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            File newFile = new File(f.getAbsolutePath() + ".txt");

            FileWriter fw = new FileWriter(newFile);
            PrintWriter pw = new PrintWriter(fw);
            String fileContent = this.txt.getText();
            pw.write(fileContent);

            pw.close();
            fw.close();

            this.openingFile = newFile;
            this.setTitle(this.openingFile.getName() + " - My Text Editor");
        }
    }

    private void menuSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSaveAsActionPerformed
        try {
            saveAs();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error while saving file!");
        }
    }//GEN-LAST:event_menuSaveAsActionPerformed

    private void menuExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_menuExitActionPerformed

    private void menuSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSelectAllActionPerformed
        selectAll();
    }//GEN-LAST:event_menuSelectAllActionPerformed

    private void menuCutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCutActionPerformed
        cut();
    }//GEN-LAST:event_menuCutActionPerformed

    private void menuCopyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCopyActionPerformed
        copy();
    }//GEN-LAST:event_menuCopyActionPerformed

    private void menuPasteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuPasteActionPerformed
        paste();
    }//GEN-LAST:event_menuPasteActionPerformed

    private void menuUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuUndoActionPerformed
        undo();
    }//GEN-LAST:event_menuUndoActionPerformed

    private void menuRedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRedoActionPerformed
        redo();
    }//GEN-LAST:event_menuRedoActionPerformed

    private void menuFindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFindActionPerformed
        FindDialog dialog = new FindDialog(this, true);
    }//GEN-LAST:event_menuFindActionPerformed

    private void menuReplaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuReplaceActionPerformed
        ReplaceDialog dialog = new ReplaceDialog(this, true);
    }//GEN-LAST:event_menuReplaceActionPerformed

    private void menuChangeFontActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuChangeFontActionPerformed

        Font initialFont = this.txt.getFont();
        Font font = JFontChooser.showDialog(this, "Choose text font", "This is a text", initialFont);

        if (font != null) {
            this.txt.setFont(font);
        }
    }//GEN-LAST:event_menuChangeFontActionPerformed

    public JTextArea getTxt() {
        return txt;
    }

    public Stack<String> getUndoStack() {
        return undoStack;
    }

    private void selectAll() {
        if (txt.getText().isEmpty()) {
            return;
        }

        txt.setSelectionStart(0);

    }

    private void cut() {
        if (this.txt.getText().isEmpty()) {
            return;
        }

        String cuttingText = this.txt.getSelectedText();
        if (cuttingText == null) {
            return;
        }

        this.buffer = cuttingText;
        int startIndex = this.txt.getSelectionStart();
        int endIndex = this.txt.getSelectionEnd();

        String newText = this.txt.getText().substring(0, startIndex)
                + this.txt.getText().substring(endIndex, this.txt.getText().length());

        this.txt.setText(newText);

        this.cutting = true;
    }

    private void paste() {
        if (this.buffer.isEmpty()) {
            return;
        }

        int cursorPosition = this.txt.getCaretPosition();

        String oldText = this.txt.getText();

        String newText = oldText.substring(0, cursorPosition)
                + this.buffer
                + oldText.substring(cursorPosition, oldText.length());

        this.txt.setText(newText);

        if (this.cutting) {
            this.buffer = "";
            this.cutting = false;
        }
    }

    private void copy() {
        if (this.txt.getText().isEmpty()) {
            return;
        }

        String copyText = this.txt.getSelectedText();
        if (copyText == null) {
            return;
        }

        this.buffer = copyText;

    }

    private void undo() {
        if (this.undoStack.isEmpty()) {

            return;
        }

        String earlierText = this.undoStack.pop();

        this.txt.setText(earlierText);
        this.redoStack.push(earlierText);
    }

    private void redo() {
        if (this.redoStack.isEmpty()) {
            return;
        }

        String laterText = this.redoStack.pop();
        this.txt.setText(laterText);
        this.undoStack.push(laterText);
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MTE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MTE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MTE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MTE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MTE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem menuChangeFont;
    private javax.swing.JMenuItem menuCopy;
    private javax.swing.JMenuItem menuCut;
    private javax.swing.JMenuItem menuExit;
    private javax.swing.JMenuItem menuFind;
    private javax.swing.JMenuItem menuNew;
    private javax.swing.JMenuItem menuOpen;
    private javax.swing.JMenuItem menuPaste;
    private javax.swing.JMenuItem menuRedo;
    private javax.swing.JMenuItem menuReplace;
    private javax.swing.JMenuItem menuSave;
    private javax.swing.JMenuItem menuSaveAs;
    private javax.swing.JMenuItem menuSelectAll;
    private javax.swing.JMenuItem menuUndo;
    private javax.swing.JTextArea txt;
    // End of variables declaration//GEN-END:variables

    @Override
    public void run() {
        if (this.txt.getText().isEmpty()) {
            this.undoStack.push("");
        }
        while (true) {

            String prevText = this.txt.getText();
            while (prevText.equals(this.txt.getText())) {

            }

            if (!this.txt.getText().isEmpty()) {
                this.undoStack.push(this.txt.getText());
            }

            try {
                Thread.sleep(STACK_DELAY);
            } catch (InterruptedException ex) {
                System.err.println("Error when sleeping thread!");
            }
        }
    }
}
