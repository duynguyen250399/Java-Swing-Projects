package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Game extends JPanel{
	private final int SCREEN_WIDTH = 500;
	private final int SCREEN_HEIGHT = 500;
	private int boardSize;
	private int tileWidth;
	private int tileHeight;
	private Color tile_color = Color.RED;
	
	private final Color NUMBER_COLOR = Color.WHITE;
	private final Font NUMBER_FONT = new Font("sanserif", Font.BOLD, 24);
	private FontMetrics fontMetrics = null;
	private final Cursor HAND_CURSOR = new Cursor(Cursor.HAND_CURSOR);
	private final Cursor DEFAULT_CURSOR = new Cursor(Cursor.DEFAULT_CURSOR);
	private int[] tiles;
	private int blankPosition;
	private int mouseEnteredIndex = -1;
	private GameUI gameUI;
	
	
	public Game(int boardSize) {
		
		this.boardSize = boardSize;
		this.tileWidth = SCREEN_WIDTH / this.boardSize;
		this.tileHeight = SCREEN_HEIGHT / this.boardSize;
		setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
	
		generateTiles();
		shuffle();
		
		
		this.addMouseListener(new GameMouseListener());
		this.addMouseMotionListener(new GameMouseMotionListener());
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		drawGrid(g2d);
	}
	
	private void drawGrid(Graphics2D g2d) {	
		
		for(int y = 0; y < boardSize; y++) {
			for(int x = 0; x < boardSize; x++) {
				int index = x + y * boardSize;				
				if(index != this.blankPosition) {
					if(this.mouseEnteredIndex != -1) {
						if(index == this.mouseEnteredIndex) {
							this.tile_color = Color.BLACK;
						}
						else {
							this.tile_color = Color.RED;
						}
					}
					
					g2d.setColor(this.tile_color);
					int xTile = x * tileWidth - 1;
					int yTile = y * tileHeight + 1;
					g2d.fillRect(xTile, yTile, tileWidth - 1, tileHeight - 1);
					
					String tileNumber = this.tiles[index] + "";
					g2d.setColor(NUMBER_COLOR);
					g2d.setFont(NUMBER_FONT);
					this.fontMetrics = g2d.getFontMetrics();
					int xString = xTile + ((tileWidth - 1) - fontMetrics.stringWidth(tileNumber)) / 2;
					int yString = yTile + ((tileHeight - 1) - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent();
					g2d.drawString(tileNumber, xString, yString);
				}
				
			}
		}
	}
	
	private void generateTiles() {
		this.tiles = new int[boardSize * boardSize];
		
		for(int i = 0; i < this.tiles.length; i++) {
			this.tiles[i] = i;
		}
	}
	
	private void shuffle() {
		Random random = new Random();	
		for(int i = 0; i < this.tiles.length; i++) {
			int randomIndex = random.nextInt(this.tiles.length);
			int temp = this.tiles[i];
			this.tiles[i] = this.tiles[randomIndex];
			this.tiles[randomIndex] = temp;
		}
		
		for (int i = 0; i < this.tiles.length; i++) {
			if(this.tiles[i] == 0) {
				this.blankPosition = i;
				break;
			}
		}
		
	}
	
	private boolean isSolved() {
		for (int i = 0; i < tiles.length - 1; i++) {
			if(this.tiles[i] != i + 1) {
				return false;
			}
		}
		return true;
	}
	
	public void resetGame() {
		generateTiles();
		shuffle();
		repaint();
	}
	
	
	
	public int getBoardSize() {
		return boardSize;
	}

	public void setBoardSize(int boardSize) {
		this.boardSize = boardSize;
	}



	public void setGameUI(GameUI gameUI) {
		this.gameUI = gameUI;
	}



	private class GameMouseListener extends MouseAdapter{

		@Override
		public void mousePressed(MouseEvent e) {
			
			int xMouse = e.getX();
			int yMouse = e.getY();
			
			int clickCol = xMouse / tileWidth;
			int clickRow = yMouse / tileHeight;
			
			
			if(clickCol < 0 || clickCol >= boardSize || clickRow < 0 || clickRow >= boardSize) {
				return;
			}
			
			int blankRow = blankPosition / boardSize;
			int blankCol = blankPosition % boardSize;
			
			int clickPos = clickCol + clickRow * boardSize;
			
			int moveBlankDir = 0;
			
			if(clickCol == blankCol && Math.abs(clickRow - blankRow) == 1) {				
				moveBlankDir = (clickRow - blankRow) > 0 ? boardSize : -boardSize;
			}
			else if(clickRow == blankRow && Math.abs(clickCol - blankCol) == 1) {
				moveBlankDir = (clickCol - blankCol) > 0 ? 1 : -1;
			}
			
			if(moveBlankDir != 0) {
				do {
					int newBlankPos = blankPosition + moveBlankDir;
					tiles[blankPosition] = tiles[newBlankPos];
					blankPosition = newBlankPos;
				}
				while(blankPosition != clickPos);
				tiles[blankPosition] = 0;
				gameUI.updateGameUI();
				
			}
			repaint();
			
			
			
			if(isSolved()) {
				JOptionPane.showMessageDialog(null, "Congratulation!!! You win!");
				resetGame();
				gameUI.resetUI();
			}
		}

		@Override
		public void mouseEntered(MouseEvent e) {		
			setCursor(HAND_CURSOR);
		}

		@Override
		public void mouseExited(MouseEvent e) {
			setCursor(DEFAULT_CURSOR);

		}

	}
	
	private class GameMouseMotionListener extends MouseMotionAdapter{
		@Override
		public void mouseMoved(MouseEvent e) {
			int xMouse = e.getX();
			int yMouse = e.getY();
			
			int xPos = xMouse / tileWidth;
			int yPos = yMouse / tileHeight;
			
			
			if(xPos < 0 || xPos >= boardSize || yPos < 0 || yPos >= boardSize || (xPos + yPos * boardSize) == blankPosition) {
				return;
			}
			
			setCursor(HAND_CURSOR);
			if((xPos + yPos * boardSize) != mouseEnteredIndex) {
				mouseEnteredIndex = xPos + yPos * boardSize;
			}
			
			
			repaint();
		}
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(() ->{
			
			GameMenu startingScreen = new GameMenu();		
			
		});
	}
}
