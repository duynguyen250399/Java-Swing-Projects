package game;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GameUI extends JPanel implements Runnable{
	private JLabel moveCountLabel;
	private JLabel timeElapsedLabel;
	private JButton btnNewGame;
	
	private final int TIME_TO_PLAY = 180;
	private final int WIDTH = 500;
	private final int HEIGHT = 150;
	
	private int moveCount = 0;
	private int currentTime;
	
	private Thread thread;
	
	private Game game;
	
	public GameUI() {
		
		this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.moveCount = 0;
		this.currentTime = TIME_TO_PLAY;
		this.moveCountLabel = new JLabel("Move count: " + this.moveCount);
		this.timeElapsedLabel = new JLabel("Elapsed time: " + this.currentTime + " seconds");
		this.btnNewGame = new JButton("New Game");
		
		this.setLayout(new GridLayout(3, 1));
		
		
		this.add(this.moveCountLabel);
		this.add(this.timeElapsedLabel);
		this.add(this.btnNewGame);
		
		this.btnNewGame.addActionListener(new NewGameListener());
		
		thread = new Thread(this);
		thread.start();
	}
	
	public void setGame(Game game) {
		this.game = game;
	}
	
	public void resetUI() {
		this.moveCount = 0;
		this.currentTime = TIME_TO_PLAY;
		this.moveCountLabel.setText("Move count: " + this.moveCount);
		this.timeElapsedLabel.setText("Elapsed time: " + this.currentTime + " seconds");
		
		this.thread = new Thread(this);
		this.thread.start();
	}
	
	public void updateGameUI() {
		this.moveCount += 1;
		this.moveCountLabel.setText("Move count: " + this.moveCount);
	}
	
	
	
	public int getCurrentTime() {
		return currentTime;
	}

	public void setCurrentTime(int currentTime) {
		this.currentTime = currentTime;
	}

	public JLabel getMoveCountLabel() {
		return moveCountLabel;
	}

	public JLabel getTimeElapsedLabel() {
		return timeElapsedLabel;
	}

	public JButton getBtnNewGame() {
		return btnNewGame;
	}

	public int getMoveCount() {
		return moveCount;
	}
	



	private class NewGameListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			resetUI();
			game.resetGame();
		}
		
	}

	@Override
	public void run() {
		while(this.currentTime >= 0) {
			this.timeElapsedLabel.setText("Elapsed time: " + this.currentTime + " seconds");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.currentTime = this.currentTime - 1;
		
		}
		JOptionPane.showMessageDialog(game, "Game Over!");
		resetUI();
		game.resetGame();
	}
}
