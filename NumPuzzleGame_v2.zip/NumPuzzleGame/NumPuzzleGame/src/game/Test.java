package game;

public class Test {
	public static void main(String[] args) {
		GameMenu menu = new GameMenu();
	}
}
