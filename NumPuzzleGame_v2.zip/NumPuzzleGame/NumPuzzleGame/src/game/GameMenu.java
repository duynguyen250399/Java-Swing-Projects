package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameMenu extends JFrame{
	private final int WIDTH = 250;
	private final int HEIGHT = 250;
	private final Color BACKGROUND_COLOR = Color.BLACK;
	
	private final Color TEXT_COLOR = Color.BLACK;
	
	private JLabel introLabel;
	private JButton btnSizeThree;
	private JButton btnSizeFour;
	private JPanel mainPanel;
	
	private int boardSize;
	
	public GameMenu() {
		
		setTitle("Number Puzzle Game");
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(3, 1));
		mainPanel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		
		introLabel = new JLabel("--- Game Size ---");
		introLabel.setFont(new Font("sanserif", Font.BOLD, 18));
		introLabel.setForeground(TEXT_COLOR);
		
		introLabel.setSize(WIDTH, 25);
		introLabel.setHorizontalAlignment(introLabel.CENTER);
		
		btnSizeThree = new JButton("3x3");
		btnSizeFour = new JButton("4x4");
		
		mainPanel.add(introLabel);
		mainPanel.add(btnSizeThree);
		mainPanel.add(btnSizeFour);
		
		this.add(mainPanel);
		
		this.pack();
		
		this.btnSizeThree.addActionListener(new ButtonAction());
		this.btnSizeFour.addActionListener(new ButtonAction());
	
		setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	
	
	public int getBoardSize() {
		return boardSize;
	}



	private class ButtonAction implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			Object button = e.getSource();
			
			if(button == btnSizeThree) {			
				boardSize = 3;
			}
			else if(button == btnSizeFour) {
				boardSize = 4;
			}
			
			JFrame gameScreen = new JFrame("Number Puzzle Game");
			gameScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			gameScreen.setResizable(false);
			
			GameUI gameUI = new GameUI();
			Game game = new Game(boardSize);			
			gameUI.setGame(game);
			game.setGameUI(gameUI);
			
			gameScreen.add(game, BorderLayout.NORTH);
			gameScreen.add(gameUI, BorderLayout.SOUTH);
			gameScreen.pack();
			
			gameScreen.setLocationRelativeTo(null);
			
			gameScreen.setVisible(true);
			
			dispose();
		}
		
	}
	
}
