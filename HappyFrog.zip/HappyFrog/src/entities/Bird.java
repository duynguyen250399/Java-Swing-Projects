package entities;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.IOException;

import animation.Animation;
import game.Game;
import interfaces.ICollision;
import interfaces.Renderable;
import interfaces.Tickable;
import utils.ImageLoader;

public class Bird extends GameEntity implements Tickable, Renderable, ICollision {

	private BufferedImage[] birdFrames;
	private String color;
	private int deg;
	private long lastTime;

	private Animation anim;

	public Bird(String color, Game game) {
		super(game);
		this.color = color;
		this.deg = 0;
		this.birdFrames = new BufferedImage[3];

		// Loading bird animation
		try {
			BufferedImage bird1 = ImageLoader.getImage(this.color + "bird-downflap");
			BufferedImage bird2 = ImageLoader.getImage(this.color + "bird-midflap");
			BufferedImage bird3 = ImageLoader.getImage(this.color + "bird-upflap");
			this.birdFrames[0] = bird1;
			this.birdFrames[1] = bird2;
			this.birdFrames[2] = bird3;
		} catch (IOException e) {
			System.out.println("Error while loading bird animation!");
		}

		this.width = this.birdFrames[0].getWidth();
		this.height = this.birdFrames[0].getHeight();

		this.anim = new Animation(200, this.birdFrames);
		this.lastTime = System.currentTimeMillis();
	}

	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void setDefaultPosition() {
		int defaultBirdPositionX = game.getWidth() / 2 - this.width - 50;
		int defaultBirdPositionY = game.getHeight() / 2 - this.height;

		this.setPosition(defaultBirdPositionX, defaultBirdPositionY);
	}

	
	@Override
	public void tick() {
		this.y += this.speed;
		updateCollisionBox();
		this.anim.tick();
	}

	@Override
	public void render(Graphics2D g2d) {
		g2d.drawImage(this.anim.getCurrentFrame(), x, y, this.width, this.height, null);
	}

	@Override
	public void updateCollisionBox() {
		this.collisionBox = new Rectangle(this.x + 3, this.y + 3, this.width - 3, this.height - 3);
	}

}
