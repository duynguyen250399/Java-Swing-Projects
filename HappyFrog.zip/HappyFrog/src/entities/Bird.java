package entities;


public class Bird extends GameEntity{
	
}
