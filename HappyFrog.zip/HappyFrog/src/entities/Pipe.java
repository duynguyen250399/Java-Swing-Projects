package entities;

import java.awt.Graphics2D;
import java.awt.Rectangle;

import game.Game;
import interfaces.ICollision;
import interfaces.Renderable;

public class Pipe extends GameEntity implements Renderable, ICollision{

	public Pipe(Game game) {
		super(game);
	}

	@Override
	public void render(Graphics2D g2d) {
		g2d.drawImage(this.image, this.x, this.y, this.width, this.height, null);
	}

	@Override
	public void updateCollisionBox() {
		this.collisionBox = new Rectangle(x, y, width, height);
	}

}
