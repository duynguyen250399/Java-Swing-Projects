package entities;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import game.Game;
import interfaces.Renderable;
import interfaces.Tickable;
import utils.ImageLoader;

public class Pipes extends ArrayList<Pipe> implements Tickable, Renderable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int numOfPipes;
	private Game game;

	public Pipes(int numOfPipes, Game game) {
		this.numOfPipes = numOfPipes;
		this.game = game;
	}
	
	@Override
	public void tick() {
		for (int i = 0; i < this.size(); i += 2) {
			Pipe top = this.get(i);
			Pipe down = this.get(i + 1);
			if (top.getX() + top.getImage().getWidth() <= 0) {

				int newX = game.getWidth() + randomInRange(370, 400);
				top.setX(newX);
				down.setX(newX);

				int verticalSpace = randomInRange(100, 150);

				int topHeight = randomInRange(30, top.getImage().getHeight());
				int downHeight = game.getHeight() - verticalSpace - topHeight;
				if (downHeight > down.getImage().getHeight()) {
					downHeight = down.getImage().getHeight();
				}

				int topY = 0;
				int downY = game.getHeight() - downHeight;

				top.setY(topY);
				top.setHeight(topHeight);
				down.setY(downY);
				down.setHeight(downHeight);
				
			}
			top.setX(top.getX() - game.getGameSpeed());
			down.setX(down.getX() - game.getGameSpeed());

			top.updateCollisionBox();
			down.updateCollisionBox();
		}
	}
	
	@Override
	public void render(Graphics2D g2d) {
		for (int i = 0; i < this.size(); i++) {

			Pipe p = this.get(i);

			p.render(g2d);
		}
	}

	public void generate() {
		if (!this.isEmpty()) {
			this.clear();
		}

		for (int i = 0; i < this.numOfPipes; i++) {
			Pipe p = new Pipe(this.game);
			BufferedImage pipeImage = null;
			try {
				if (i % 2 == 0) {
					pipeImage = ImageLoader.getImage("pipe-green-down");
				} else {
					pipeImage = ImageLoader.getImage("pipe-green-up");
				}
			} catch (IOException ex) {
				System.out.println("Error while loading pipe images!");
			}
			p.setImage(pipeImage);
			p.setSize(pipeImage.getWidth(), pipeImage.getHeight());
			this.add(p);
		}

		for (int i = 0; i < this.numOfPipes; i += 2) {

			Pipe top = this.get(i);
			Pipe down = this.get(i + 1);
			int x;

			if (i == 0) {
				x = 250;
			} else {
				int horizontalSpace = randomInRange(150, 200);

				x = this.get(i - 1).getX() + horizontalSpace;
			}

			top.setX(x);
			down.setX(x);

			int verticalSpace = randomInRange(100, 150);

			int topHeight = randomInRange(30, top.getImage().getHeight());
			int downHeight = game.getHeight() - verticalSpace - topHeight;
			if (downHeight > down.getImage().getHeight()) {
				downHeight = down.getImage().getHeight();
			}

			int topY = 0;
			int downY = game.getHeight() - downHeight;

			top.setY(topY);
			top.setHeight(topHeight);
			down.setY(downY);
			down.setHeight(downHeight);
			
			BufferedImage pipeTopImage = top.getImage().getSubimage(0, top.getImage().getHeight() - top.getHeight(),
					top.getWidth(), top.getHeight());
			
			BufferedImage pipeDownImage = down.getImage().getSubimage(0, 0, down.getWidth(), down.getHeight());
			top.setImage(pipeTopImage);
			down.setImage(pipeDownImage);
			
			top.updateCollisionBox();
			down.updateCollisionBox();
		}

	}

	private int randomInRange(int min, int max) {
		Random random = new Random();
		return random.nextInt(max - min) + min;
	}

}
