package entities;

import java.awt.image.BufferedImage;

public abstract class GameEntity {
	int x;
	int y;
	float speed;
	BufferedImage image;
	
	public GameEntity() {
		
	}
	
	public GameEntity(int x, int y, float speed, BufferedImage image) {
		super();
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.image = image;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public float getSpeed() {
		return speed;
	}
	public void setSpeed(float speed) {
		this.speed = speed;
	}
	public BufferedImage getImage() {
		return image;
	}
	public void setImage(BufferedImage image) {
		this.image = image;
	}
	
	
}
