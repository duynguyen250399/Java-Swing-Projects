package entities;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import game.Game;
import interfaces.Renderable;
import interfaces.Tickable;
import utils.ImageLoader;


public class Background extends GameEntity implements Tickable, Renderable{

	private BufferedImage background;
	private BufferedImage forceGround;
	private String mode;
	
	public Background(String mode, Game game) {
		super(game);
		this.mode = mode;
		this.width = game.getWidth();
		this.height = game.getHeight();
		try {
			this.background = ImageLoader.getImage("background-" + this.mode);
			this.forceGround = ImageLoader.getImage("message");
		} catch (IOException e) {
			System.out.println("Error while loading background!");
		}
		
		
	}
	
	public BufferedImage getBackgroundImage() {
		return this.background;
	}
	
	public void setBackgroundImage(String mode) {
		try {
			this.background = ImageLoader.getImage("background-" + this.mode);
		} catch (IOException e) {
			System.out.println("Error while changing background!");
		}
	}
	
	@Override
	public void tick() {
		if(this.x < -game.getWidth()) {
			this.x = 0;
		}
		this.x--;
	}

	@Override
	public void render(Graphics2D g2d) {
		if(this.background == null || this.forceGround == null) {
			System.out.println("background is null");
			return;
		}
		
		
		g2d.drawImage(this.background, this.x, 0, this.width, this.height, null);
		g2d.drawImage(this.background, this.getWidth() + this.x, 0, this.width, this.height, null);

		g2d.drawImage(this.forceGround, 0, 0, this.width, this.height, null);
	}
	
}
