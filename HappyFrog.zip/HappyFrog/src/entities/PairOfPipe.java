package entities;

import java.util.Random;

public class PairOfPipe {
	private Pipe top;
	private Pipe down;
	
	public void generate(int x) {
		Random random = new Random();
		this.top = new Pipe();
		this.down = new Pipe();
		
		this.top.setX(x);
		this.down.setX(x);
		
		
	}
}
