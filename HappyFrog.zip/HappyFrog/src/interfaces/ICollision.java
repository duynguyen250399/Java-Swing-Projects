package interfaces;

public interface ICollision {
	void updateCollisionBox();
}
