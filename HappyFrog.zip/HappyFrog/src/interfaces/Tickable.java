package interfaces;

public interface Tickable {
	void tick();
}
