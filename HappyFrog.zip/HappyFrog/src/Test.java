
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Test extends JPanel implements Runnable {

	private Thread t;
	private int x;
	private int y;
	
	private BufferedImage pipeImage;

	public Test() {
		setPreferredSize(new Dimension(500, 500));
		this.x = 0;
		this.y = 0;
		
	}

	@Override
	public void paint(Graphics g) {
		g.clearRect(0, 0, 500, 500);
		g.setColor(Color.RED);
		g.fillRect(x, y, 50, 50);
	}

	@Override
	public void addNotify() {
		super.addNotify();
		t = new Thread(this);
		t.start();
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("Test");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.add(new Test());
		frame.pack();
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);
	}

	@Override
	public void run() {

		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		int ticks = 0;

		long renderLastTime = System.nanoTime();
		double amtOfRenders = 200.0;// MAX FPS
		double renderNs = 1000000000 / amtOfRenders;
		double renderDelta = 0;

		while (true) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;			
			lastTime = now;
			while (delta >= 1) {
				x++;
				y++;
				ticks++;
				delta--;
			}

			now = System.nanoTime();
			renderDelta += (now - renderLastTime) / renderNs;
			renderLastTime = now;
			while (renderDelta >= 1) {
				repaint();
				frames++;
				renderDelta--;
			}

			if (System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println("FPS: " + frames);
				System.out.println("Ticks per second: " + ticks);
				frames = 0;
				ticks = 0;
			}
		}
	}
}
