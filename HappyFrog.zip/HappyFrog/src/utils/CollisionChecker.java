package utils;

import java.awt.Rectangle;

public class CollisionChecker {
	public static boolean isColliding(Rectangle obj1, Rectangle obj2) {
		return obj1.intersects(obj2);
	}
	
	public static boolean hitEdges(Rectangle obj, int width, int height) {
		if (obj.y + 2 < 0 || obj.y + obj.height >= height) {
			return true;
		}
		
		return false;
	}
}
