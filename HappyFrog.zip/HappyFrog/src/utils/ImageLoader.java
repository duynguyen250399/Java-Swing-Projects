package utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

public class ImageLoader {
	public static Map<String, BufferedImage> loadImages() throws IOException{
		Map<String, BufferedImage> images = new HashMap<>();
		String uri = "res/images/";
		
		File imgDir = new File(uri);
		
		File[] imageFiles = imgDir.listFiles();
		
		for (int i = 0; i < imageFiles.length; i++) {
			File file = imageFiles[i];
			BufferedImage img = ImageIO.read(file);
			String fileName = imageFiles[i].getName();
			int lastIndex = fileName.lastIndexOf(".");
			String newFileName = fileName.substring(0, lastIndex);
			
			images.put(newFileName, img);
		}

		
		return images;
	}
	
	public static BufferedImage getImage(String imgName) throws IOException {
		BufferedImage img = null;
		String uri = "res/images/" + imgName + ".png";
		File imgFile = new File(uri);
		
		img = ImageIO.read(imgFile);
		
		return img;	
	}
}
