package utils;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class ImageResizer {
	public static BufferedImage resizeImage(BufferedImage originalImage, int scaledWidth, int scaledHeight) {
		BufferedImage outputImage = new BufferedImage(scaledWidth, scaledHeight, originalImage.TYPE_INT_ARGB);
		
		Graphics2D g2d = outputImage.createGraphics();
		
		g2d.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);
		g2d.dispose();
		
		return outputImage;
	}
}
