package game;

import java.awt.Canvas;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.JPanel;

import entities.Background;
import entities.Bird;
import entities.Pipe;
import entities.Pipes;
import input.KeyManager;
import input.MouseManager;
import utils.CollisionChecker;
import utils.ImageLoader;
import utils.ImageResizer;

public class Game extends Canvas implements Runnable {
	private final int WIDTH = 350;
	private final int HEIGHT = 500;
	private float birdSpeed = 3f;
	private int gameSpeed = 1;

	private Map<String, BufferedImage> assets;

	// Graphics
	private BufferStrategy bs = null;
	private Graphics2D g2d = null;

	private Thread thread;

	// Game logic variables
	private boolean running = true;
	private boolean gameStarted = false;
	private boolean gameOver = false;
	private int score = 0;

	// Manager classes
	private KeyManager keyManager;
	private MouseManager mouseManager;

	// Entities
	private Bird bird;
	private Pipes pipes;

	private Background background;

	public Game() throws IOException {
		super();
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.assets = ImageLoader.loadImages();
		this.setCursor(new Cursor(Cursor.HAND_CURSOR));

		this.keyManager = new KeyManager(this);
		this.mouseManager = new MouseManager(this);

		this.addMouseListener(this.mouseManager);
		this.addKeyListener(this.keyManager);
	}

	// getters and setters
	public int getGameSpeed() {
		return gameSpeed;
	}

	public void setGameSpeed(int gameSpeed) {
		this.gameSpeed = gameSpeed;
	}

	public boolean isGameStarted() {
		return gameStarted;
	}

	public Bird getBird() {
		return bird;
	}

	public float getBirdSpeed() {
		return birdSpeed;
	}

	public void setBirdSpeed(float birdSpeed) {
		this.birdSpeed = birdSpeed;
	}

	public KeyManager getKeyManager() {
		return keyManager;
	}

	public MouseManager getMouseManager() {
		return mouseManager;
	}

	public boolean isGameOver() {
		return gameOver;
	}

	public void setGameStarted(boolean gameStarted) {
		this.gameStarted = gameStarted;
	}

	// Drawing methods
	private void drawScore(Graphics2D g2d) {

		String scoreString = String.valueOf(this.score);
		for (int i = 0; i < scoreString.length(); i++) {
			BufferedImage numImg = this.assets.get(scoreString.charAt(i) + "");
			g2d.drawImage(numImg, numImg.getWidth() * i, 0, numImg.getWidth(), numImg.getHeight(), null);
		}
	}

	private void drawGameOverMsg(Graphics2D g2d) {

		BufferedImage gameOverImg = this.assets.get("gameover");

		int x = this.getWidth() / 2 - (gameOverImg.getWidth() / 2);
		int y = this.getHeight() / 2 - (gameOverImg.getHeight() / 2);

		g2d.drawImage(gameOverImg, x, y, gameOverImg.getWidth(), gameOverImg.getHeight(), null);

	}

	public synchronized void start() {
		if (!this.running) {
			this.running = true;
		}

		thread = new Thread(this);
		thread.start();
	}

	public synchronized void stop() {

		if (this.running) {
			this.running = false;
		}

		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void checkIncreaseScore() {
		for (int i = 0; i < this.pipes.size(); i += 2) {
			Pipe p = this.pipes.get(i);
			int birdX = this.bird.getX() + this.bird.getWidth();
			int pipeX = p.getX() + p.getImage().getWidth();
			if (birdX == pipeX) {
				this.score++;
			}
		}
	}

	public void restartGame() {
		this.gameOver = false;
		this.gameStarted = false;
		this.score = 0;

		this.bird.setDefaultPosition();
		this.pipes.generate();
	}

	private boolean checkCollision() {
		
		if(CollisionChecker.hitEdges(this.bird.getCollisionBox(), getWidth(), getHeight())) {
			return true;
		}
	
		for (int i = 0; i < this.pipes.size(); i++) {
			Pipe p = this.pipes.get(i);
			
			if (CollisionChecker.isColliding(this.bird.getCollisionBox(), p.getCollisionBox())) {
				return true;
			}
		}
		
		return false;
	}

	@Override
	public void run() {
		init();

		// Set up game FPS
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;

		long renderLastTime = System.nanoTime();
		double amtOfRenders = 200.0;// MAX FPS
		double renderNs = 1000000000 / amtOfRenders;
		double renderDelta = 0;

		while (running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while (delta >= 1) {
				tick();

				delta--;
			}

			now = System.nanoTime();
			renderDelta += (now - renderLastTime) / renderNs;
			renderLastTime = now;
			while (renderDelta >= 1) {
				render();

				renderDelta--;
			}

		}

	}

	private void init() {

		this.pipes = new Pipes(8, this);
		this.bird = new Bird("yellow", this);
		this.bird.setDefaultPosition();
		this.bird.setCollisionBox(
				new Rectangle(this.bird.getX(), this.bird.getY(), this.bird.getWidth(), this.bird.getHeight()));

		this.pipes.generate();

		this.background = new Background("day", this);

		this.bird.setSpeed(birdSpeed);

		

	}

	private void tick() {

		if (!this.gameStarted) {
			this.background.tick();
		} else {

			this.mouseManager.tick();
			this.keyManager.tick();

			// pipe ticks
			this.pipes.tick();
			// bird ticks
			this.bird.tick();

			// check for increasing the game score
			checkIncreaseScore();

			// check if bird hits any of pipes
			boolean collided = checkCollision();
			
			if (collided) {
				gameOver = true;
				gameStarted = false;
			}

		}
	}

	private void render() {
		bs = this.getBufferStrategy();
		if (bs == null) {
			super.createBufferStrategy(3);
			return;
		}

		g2d = (Graphics2D) bs.getDrawGraphics();

		if (!gameOver) {
			if (!gameStarted) {
				this.background.render(g2d);
			} else {
				g2d.drawImage(this.background.getBackgroundImage(), 0, 0, this.background.getWidth(),
						this.background.getHeight(), null);
				this.pipes.render(g2d);
				this.bird.render(g2d);
				drawScore(g2d);
			}
		} else {
			drawGameOverMsg(g2d);
		}

		bs.show();
		g2d.dispose();
	}

}
