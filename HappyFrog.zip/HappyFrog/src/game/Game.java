package game;

import java.awt.Canvas;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.JPanel;

import entities.Bird;
import entities.Pipe;
import utils.ImageLoader;
import utils.ImageResizer;

public class Game extends Canvas implements Runnable {
	private final int WIDTH = 350;
	private final int HEIGHT = 500;
	private final int MAX_PIPE = 4;
	private final float BIRD_SPEED = 3f;
	private final int GAME_SPEED = 1;
	private static Random random = new Random();

	private Map<String, BufferedImage> assets;

	// Graphics
	private BufferStrategy bs = null;
	private Graphics2D g2d = null;

	private Thread thread;

	// Game logic variables
	private boolean running = true;
	private boolean gameStarted = false;
	private boolean gameOver = false;
	private int score = 0;

	private int bgX;
	private BufferedImage background;

	private BufferedImage forceGround;

	// Entities
	private Bird bird;
	private BufferedImage[] birds = new BufferedImage[3];
	private int birdIndex = 0;
	
	private List<Pipe> pipes;

	public Game() throws IOException {
		super();
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.assets = ImageLoader.loadImages();
		this.setCursor(new Cursor(Cursor.HAND_CURSOR));

		this.pipes = new ArrayList<Pipe>();
		this.bird = new Bird();

		this.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				super.mousePressed(e);
				
				if(gameOver) {
					restartGame();
				}
				else {
					if (!gameStarted) {
						startGame();
					}
					else {
						bird.setSpeed(-BIRD_SPEED);
					}
					
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				super.mouseReleased(e);
				if(!gameOver) {
					bird.setSpeed(BIRD_SPEED);
				}
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				bird.setY(bird.getY() - 10);
			}

		});
	}

	// Drawing methods
	private void drawBackground(Graphics2D g2d) {

		g2d.drawImage(this.background, bgX, 0, this.getWidth(), this.getHeight(), null);
		g2d.drawImage(this.background, this.getWidth() + bgX, 0, this.getWidth(), this.getHeight(), null);

		g2d.drawImage(this.forceGround, 0, 0, this.getWidth(), this.getHeight(), null);
	}

	private void drawInGameBackground(Graphics2D g2d) {
		g2d.drawImage(this.background, 0, 0, this.getWidth(), this.getHeight(), null);
	}

	private void drawBird(Graphics2D g2d) {

		g2d.drawImage(this.birds[birdIndex], this.bird.getX(), this.bird.getY(), this.bird.getImage().getWidth(),
				this.bird.getImage().getHeight(), null);
	}

	private void drawScore(Graphics2D g2d) {

		String scoreString = String.valueOf(this.score);
		for (int i = 0; i < scoreString.length(); i++) {
			BufferedImage numImg = this.assets.get(scoreString.charAt(i) + "");
			g2d.drawImage(numImg, numImg.getWidth() * i, 0, numImg.getWidth(), numImg.getHeight(), null);
		}
	}

	private void drawGameOverMsg(Graphics2D g2d) {
		
		BufferedImage gameOverImg = this.assets.get("gameover");
		
		int x = this.getWidth() / 2 - (gameOverImg.getWidth() / 2);
		int y = this.getHeight() / 2 - (gameOverImg.getHeight() / 2);
	
		g2d.drawImage(gameOverImg, x, y, gameOverImg.getWidth(), gameOverImg.getHeight(), null);
		
	}

	private void drawPipes(Graphics2D g2d) {
		for (int i = 0; i < this.pipes.size(); i++) {

			Pipe p = this.pipes.get(i);

			BufferedImage subImage = null;

			if (i % 2 == 0) {
				subImage = p.getImage().getSubimage(0, p.getImage().getHeight() - p.getHeight(),
						p.getImage().getWidth(), p.getHeight());
			} else {
				subImage = p.getImage().getSubimage(0, 0, p.getImage().getWidth(), p.getHeight());
			}

			g2d.drawImage(subImage, p.getX(), p.getY(), subImage.getWidth(), subImage.getHeight(), null);
		}
	}

	public synchronized void start() {
		if (!this.running) {
			this.running = true;
		}

		thread = new Thread(this);
		thread.start();
	}

	public synchronized void stop() {
		
		if (this.running) {
			this.running = false;
		}

		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void init() {
		this.bgX = 0;

		this.background = ImageResizer.resizeImage(this.assets.get("background-day"), this.getWidth(),
				this.getHeight());
		this.forceGround = ImageResizer.resizeImage(this.assets.get("message"), this.getWidth(), this.getHeight());
		
		this.birds[0] = this.assets.get("bluebird-downflap");
		this.birds[1] = this.assets.get("bluebird-midflap");
		this.birds[2] = this.assets.get("bluebird-upflap");
	}

	private void startGame() {
		this.gameStarted = true;
		setUpPlayer();
		setUpPipes();

	}

	private void checkIncreaseScore() {
		for (int i = 0; i < this.pipes.size(); i += 2) {
			Pipe p = this.pipes.get(i);
			int birdX = this.bird.getX() + this.bird.getImage().getWidth();
			int pipeX = p.getX() + p.getImage().getWidth();
			if (birdX == pipeX) {
				this.score++;
			}
		}
	}

	private void setUpPlayer() {
		this.bird.setSpeed(BIRD_SPEED);

		BufferedImage birdImage = this.assets.get("bluebird-midflap");
		this.bird.setImage(birdImage);

		int defaultBirdPositionX = WIDTH / 2 - this.bird.getImage().getWidth() - 50;
		int defaultBirdPositionY = HEIGHT / 2 - this.bird.getImage().getHeight();

		this.bird.setX(defaultBirdPositionX);
		this.bird.setY(defaultBirdPositionY);
	}

	private int randomInRange(int min, int max) {
		return random.nextInt(max - min) + min;
	}

	private void setUpPipes() {
		if (!this.pipes.isEmpty()) {
			this.pipes.clear();
		}

		for (int i = 0; i < MAX_PIPE * 2; i++) {
			Pipe p = new Pipe();
			BufferedImage pipeImage = null;
			if (i % 2 == 0) {
				pipeImage = this.assets.get("pipe-green-down");
			} else {
				pipeImage = this.assets.get("pipe-green-up");
			}
			p.setImage(pipeImage);
			this.pipes.add(p);
		}

		for (int i = 0; i < MAX_PIPE * 2; i += 2) {

			Pipe top = this.pipes.get(i);
			Pipe down = this.pipes.get(i + 1);
			int x;

			if (i == 0) {
				x = 250;
			} else {
				int horizontalSpace = randomInRange(150, 200);

				x = this.pipes.get(i - 1).getX() + horizontalSpace;
			}

			top.setX(x);
			down.setX(x);

			int verticalSpace = randomInRange(100, 150);

			int topHeight = randomInRange(30, top.getImage().getHeight());
			int downHeight = this.getHeight() - verticalSpace - topHeight;
			if (downHeight > down.getImage().getHeight()) {
				downHeight = down.getImage().getHeight();
			}

			int topY = 0;
			int downY = this.getHeight() - downHeight;

			top.setY(topY);
			top.setHeight(topHeight);
			down.setY(downY);
			down.setHeight(downHeight);
		}

//		for (int i = 0; i < this.pipes.size(); i++) {
//			System.out.println("pipe " + i + ": h-" + this.pipes.get(i).getHeight() + " w-"
//					+ this.pipes.get(i).getImage().getWidth());
//		}

	}

	private void restartGame() {
		this.gameOver = false;
		this.score = 0;
		
	
	}

	private boolean checkCollision() {

		Rectangle bird = new Rectangle(this.bird.getX() - 2, this.bird.getY() - 2, this.bird.getImage().getWidth() - 2,
				this.bird.getImage().getHeight() - 2);

		if (bird.y + 2 < 0 || bird.y + bird.height >= this.getHeight()) {
			return true;
		}

		for (int i = 0; i < this.pipes.size(); i++) {
			Pipe p = this.pipes.get(i);
			Rectangle pipe = new Rectangle(p.getX(), p.getY(), p.getImage().getWidth(), p.getHeight());
			if (bird.intersects(pipe)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void run() {
		init();

		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;

		long renderLastTime = System.nanoTime();
		double amtOfRenders = 200.0;// MAX FPS
		double renderNs = 1000000000 / amtOfRenders;
		double renderDelta = 0;

		while (running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while (delta >= 1) {
				tick();

				delta--;
			}

			now = System.nanoTime();
			renderDelta += (now - renderLastTime) / renderNs;
			renderLastTime = now;
			while (renderDelta >= 1) {
				render();

				renderDelta--;
			}

		}
		
		
	}

	private void tick() {

		if (!this.gameStarted) {
			bgX--;
			if (bgX < -this.getWidth()) {
				bgX = 0;
			}
		} else {
			this.birdIndex++;
			if(this.birdIndex >= 3) {
				this.birdIndex = 0;
			}
			// pipe ticks
			for (int i = 0; i < this.pipes.size(); i += 2) {
				Pipe top = this.pipes.get(i);
				Pipe down = this.pipes.get(i + 1);
				if (top.getX() + top.getImage().getWidth() <= 0) {

					int newX = this.getWidth() + randomInRange(370, 400);
					top.setX(newX);
					down.setX(newX);

					int verticalSpace = randomInRange(100, 150);

					int topHeight = randomInRange(30, top.getImage().getHeight());
					int downHeight = this.getHeight() - verticalSpace - topHeight;
					if (downHeight > down.getImage().getHeight()) {
						downHeight = down.getImage().getHeight();
					}

					int topY = 0;
					int downY = this.getHeight() - downHeight;

					top.setY(topY);
					top.setHeight(topHeight);
					down.setY(downY);
					down.setHeight(downHeight);

				}
				top.setX(top.getX() - GAME_SPEED);
				down.setX(down.getX() - GAME_SPEED);

			}

			// bird ticks
			this.bird.setY(this.bird.getY() + (int) this.bird.getSpeed());

			// check for increasing the game score
			checkIncreaseScore();

			// check if bird hits any of pipes
			boolean collided = checkCollision();
			if (collided) {
				gameOver = true;
				gameStarted = false;
			}

		}
	}

	private void render() {
		bs = this.getBufferStrategy();
		if (bs == null) {
			super.createBufferStrategy(3);
			return;
		}

		g2d = (Graphics2D) bs.getDrawGraphics();

		if (!gameOver) {
			if (!gameStarted) {
				drawBackground(g2d);
			} else {
				drawInGameBackground(g2d);
				drawPipes(g2d);
				drawBird(g2d);
				drawScore(g2d);
			}
		}
		else {
			drawGameOverMsg(g2d);
		}
		
		bs.show();
		g2d.dispose();
	}
}
