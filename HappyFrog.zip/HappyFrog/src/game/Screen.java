package game;

import javax.swing.JFrame;

public class Screen extends JFrame{
	
	private Game game;
	
	public Screen() {		
		this.setTitle("Flappy Bird");		
	}
	
	public void setGame(Game game) {
		this.game = game;
	}
	
	
	public void init() {
		if(this.game != null) {
			this.add(this.game);
			this.pack();
			this.setResizable(false);
			this.setLocationRelativeTo(null);
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		}
	}
	
	public void display() {
		this.setVisible(true);
	}
}
