package game;

import java.awt.EventQueue;
import java.io.IOException;

public class Launcher {
	public static void main(String[] args) throws IOException {
		EventQueue.invokeLater(() ->{
			Game game;
			try {
				game = new Game();
				Screen screen = new Screen();
				screen.setGame(game);
				
				screen.init();	
				screen.display();
				
				game.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		});
	}
}
