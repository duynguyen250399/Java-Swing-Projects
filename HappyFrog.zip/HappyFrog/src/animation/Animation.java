package animation;

import java.awt.image.BufferedImage;

import interfaces.Tickable;

public class Animation implements Tickable{
	private int speed;
	private int index;
	private BufferedImage[] frames;
	
	private long lastTime, timeCounter;
	
	public Animation(int speed, BufferedImage[] frames) {
		this.speed = speed;
		this.frames = frames;
		this.index = 0;
		this.timeCounter = 0;
		this.lastTime = System.currentTimeMillis();
	}

	@Override
	public void tick() {
		this.timeCounter += System.currentTimeMillis() - this.lastTime;
		this.lastTime = System.currentTimeMillis();
		
		if(this.timeCounter > this.speed) {
			this.index++;
			this.timeCounter = 0;
			if(this.index >= this.frames.length) {
				this.index = 0;
			}
		}
	}
	
	public BufferedImage getCurrentFrame() {
		return this.frames[index];
	}
}
