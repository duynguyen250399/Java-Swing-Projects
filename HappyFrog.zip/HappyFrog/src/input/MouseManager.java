package input;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import game.Game;
import interfaces.Tickable;

public class MouseManager implements MouseListener, MouseMotionListener, Tickable {

	private int mouseX;
	private int mouseY;

	private boolean rightClick;
	private boolean leftClick;

	private boolean isPressed;
	private boolean hovering;

	private Game game;

	public MouseManager(Game game) {
		this.game = game;
	}

	public int getMouseX() {
		return mouseX;
	}

	public int getMouseY() {
		return mouseY;
	}

	public boolean isRightClick() {
		return rightClick;
	}

	public boolean isLeftClick() {
		return leftClick;
	}

	public boolean isPressed() {
		return isPressed;
	}

	public boolean isHovering() {
		return hovering;
	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		this.hovering = true;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		this.hovering = false;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			this.leftClick = true;
			if (!game.isGameStarted()) {
				game.setGameStarted(true);
			}
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			this.rightClick = true;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			this.leftClick = false;
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			this.rightClick = false;
		}
	}

	@Override
	public void tick() {

		if (game.isGameOver()) {
			game.restartGame();
			return;
		}

		if (game.isGameStarted() && this.leftClick && !game.getKeyManager().isPressed()) {
			game.getBird().setSpeed(-game.getBirdSpeed());

		}
		if (game.isGameStarted() && !this.leftClick && !game.getKeyManager().isPressed()) {
			game.getBird().setSpeed(game.getBirdSpeed());
		}

	}

}
