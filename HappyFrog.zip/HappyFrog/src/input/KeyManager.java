package input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import game.Game;
import interfaces.Tickable;

public class KeyManager implements KeyListener, Tickable{
	
	private boolean keys[];
	private boolean isPressed;

	private Game game;
	
	public KeyManager(Game game) {
		this.game = game;
		this.keys = new boolean[256];
		this.isPressed = false;
	}

	public boolean isPressed() {
		return isPressed;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		this.keys[e.getKeyCode()] = true;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		this.keys[e.getKeyCode()] = false;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	@Override
	public void tick() {
		this.isPressed = keys[KeyEvent.VK_SPACE];
		
		if(this.isPressed && !game.getMouseManager().isLeftClick()) {
			game.getBird().setSpeed(-game.getBirdSpeed());
		}
		if(!this.isPressed && !game.getMouseManager().isLeftClick()) {
			game.getBird().setSpeed(game.getBirdSpeed());
		}
	}
	
}
