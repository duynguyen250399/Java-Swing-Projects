/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Admin
 */
public class DBConnection {
    public static Connection makeConnection() throws ClassNotFoundException, SQLException{
        String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        Class.forName(driver);
        String connectionString = "jdbc:sqlserver://localhost:1433;databaseName=ProductDB";
        Connection con = DriverManager.getConnection(connectionString, "sa", "123");
        
        return con;
    }
}
