/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models.product;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Admin
 */
public class ProductTableModel extends AbstractTableModel{
    
    private String[] header;
    private int[] indexes;
    private Vector<ProductDTO> data;

    public ProductTableModel(String[] header, int[] indexes) {
        this.header = new String[header.length];
        for (int i = 0; i < this.header.length; i++) {
            this.header[i] = header[i];
        }
        
        this.indexes = new int[indexes.length];
        for (int i = 0; i < this.indexes.length; i++) {
            this.indexes[i] = indexes[i];
        }
        
        this.data = new Vector<>();
    }
    
    

    public Vector<ProductDTO> getData() {
        return data;
    }  
    

    @Override
    public boolean isCellEditable(int i, int i1) {
        return false;
    }      

    @Override
    public int getRowCount() {
        return this.data.size();
    }

    @Override
    public int getColumnCount() {
        return this.header.length;
    }

    @Override
    public String getColumnName(int col) {
        return (col >= 0 && col < header.length) ? header[col] : "";
    }   
    

    @Override
    public Object getValueAt(int row, int col) {
        if(row < 0 || row >= data.size() || col < 0 || col >= header.length){
            return null;
        }
        
        ProductDTO product = data.get(row);
        
        switch(this.indexes[col]){
            case 0:
                return product.getId();
            case 1:
                return product.getCategory();
            case 2:
                return product.getName();
            case 3:
                return product.getQuantity();
            case 4:
                return product.getPrice();
        }
        
        return null;
    }
    
    
    
}
