/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.category.CategoryDTO;
import utils.DBConnection;

/**
 *
 * @author Admin
 */
public class ProductDAO {

    public boolean insertNewProduct(String productID, String categoryID, String name, int quantity, float price) throws ClassNotFoundException, SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        
        try{
            con = DBConnection.makeConnection();
            if(con != null){
                String sql =  "insert into tblProduct values(?,?,?,?,?)";               
                stm = con.prepareStatement(sql);
                stm.setString(1, productID);
                stm.setString(2, categoryID);
                stm.setString(3, name);
                stm.setInt(4, quantity);
                stm.setFloat(5, price);
                int row = stm.executeUpdate();
                
                if(row > 0){
                    return true;
                }
                
            }
        }
        finally{
            if(stm != null){
                stm.close();
            }
            if(con != null){
                con.close();
            }
        }
        
        return false;
    }
    
    public boolean updateProduct(String oldProductID, String newProductID, String productName, int quantity, float price) throws ClassNotFoundException, SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        
        try{
            con = DBConnection.makeConnection();
            if(con != null){
                String sql =  "update tblProduct "
                        + "set productId = ?, name = ?, quantity = ?, price = ? "
                        + "where productId = ?";               
                stm = con.prepareStatement(sql);
                stm.setString(1, newProductID);
                stm.setString(2, productName);
                stm.setInt(3, quantity);
                stm.setFloat(4, price);
                stm.setString(5, oldProductID);
                int row = stm.executeUpdate();
                
                if(row > 0){
                    return true;
                }
                
            }
        }
        finally{
            if(stm != null){
                stm.close();
            }
            if(con != null){
                con.close();
            }
        }
        
        return false;
    }

    public boolean removeProduct(String productID) throws ClassNotFoundException, SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        
        try{
            con = DBConnection.makeConnection();
            if(con != null){
                String sql =  "delete from tblProduct where productId = ?";               
                stm = con.prepareStatement(sql);
                stm.setString(1, productID);
               
                int row = stm.executeUpdate();
                
                if(row > 0){
                    return true;
                }
                
            }
        }
        finally{
            if(stm != null){
                stm.close();
            }
            if(con != null){
                con.close();
            }
        }
        
        return false;
    }

    public ArrayList<ProductDTO> getProductsByCategoryID(String categoryID) throws ClassNotFoundException, SQLException {
        ArrayList<ProductDTO> products = new ArrayList<>();
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            con = DBConnection.makeConnection();
            if (con != null) {
                String sql = "select c.name categoryName, p.productId, p.name productName, p.quantity, p.price "
                        + "from tblProduct p join tblCategory c on p.categoryId = c.categoryId "
                        + "where p.categoryId = ?";
                stm = con.prepareStatement(sql);
                stm.setString(1, categoryID);
                rs = stm.executeQuery();

                while (rs.next()) {                
                    String categoryName = rs.getString("categoryName");
                    String productID = rs.getString("productId");
                    String productName = rs.getString("productName");
                    int quantity = rs.getInt("quantity");
                    float price = rs.getFloat("price");
                    
                    ProductDTO dto = new ProductDTO(new CategoryDTO(categoryID, categoryName), productID, productName, quantity, price);
                    products.add(dto);
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return products;
    }

}
