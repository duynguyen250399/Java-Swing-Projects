/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import data.Data;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import models.category.CategoryDAO;
import models.category.CategoryDTO;
import models.product.ProductDAO;
import models.product.ProductDTO;
import models.product.ProductTableModel;

/**
 *
 * @author Admin
 */
public class ProductManagement extends javax.swing.JFrame {

    private ArrayList<CategoryDTO> categories;
    private ArrayList<ProductDTO> products;
    private ProductTableModel model;

    private final String[] HEADER = {
        "Product ID", "Product Name"
    };
    private final int[] INDEXES = {0, 2}; // header indexes

    private boolean updating = false;
    private boolean creating = false;

    public ProductManagement() {
        try {
            initComponents();
            setTitle("Product Management");
            setResizable(false);
            setLocationRelativeTo(null);

            updateCategoryList();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        }

        //DefaultTableModel model = new DefaultTableModel(new Vector(), Data.getHeaders());
        this.model = new ProductTableModel(HEADER, INDEXES);

        this.tblProductDetails.setModel(model);

        this.txtCategory.setEnabled(false);

        this.txtProductID.setEditable(false);
        this.txtProductName.setEditable(false);
        this.txtPrice.setEditable(false);
        this.txtQuantity.setEditable(false);
        this.tblProductDetails.setSelectionMode(0);
        this.tblProductDetails.setColumnSelectionAllowed(false);

        this.btnSaveProduct.setEnabled(false);
        this.btnNewProduct.setEnabled(false);
        this.btnDeleteProduct.setEnabled(false);
        this.btnUpdateProduct.setEnabled(false);

    }

    public void updateCategoryList() throws ClassNotFoundException, SQLException {
        this.categories = Data.getCategoryData();
        if (this.categories.isEmpty()) {
            return;
        }

        DefaultListModel listModel = new DefaultListModel();
        for (CategoryDTO category : categories) {
            listModel.addElement(category.getName());
        }
        this.listCategory.setModel(listModel);
        this.listCategory.updateUI();
    }

    public JList<String> getListCategory() {
        return listCategory;
    }

    public ArrayList<CategoryDTO> getCategories() {
        return categories;
    }

    private boolean isValidProductData(String productID, String productName, String quantity, String price) {
        String productIDPattern = "^[A-Z][A-Z0-9]{2,10}$";
        String productNamePattern = "^[a-zA-Z0-9- ]{1,50}$";
        String quantityPattern = "\\d+";

        if (productID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Product ID required!");
            return false;
        }
        if (productName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Product Name required!");
            return false;
        }
        if (quantity.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantity required!");
            return false;
        }
        if (price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Price required!");
            return false;
        }

        if (!productID.matches(productIDPattern)) {
            JOptionPane.showMessageDialog(this, "Product ID must start by an uppercase letter\n"
                    + "At least 3 and no more than 10 letters");
            return false;
        }
        if (!productName.matches(productNamePattern)) {
            JOptionPane.showMessageDialog(this, "Product Name at least 1 and no more than 50 letters");
            return false;
        }
        try {
            int q = Integer.parseInt(quantity);
            if (q < 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be > 0");
                return false;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Quantity must be a number!");
            return false;
        }

        try {
            float p = Float.parseFloat(price);
            if (p < 0) {
                JOptionPane.showMessageDialog(this, "Price must be > 0");
                return false;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Price must be a number!");
            return false;
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        splitPane = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listCategory = new javax.swing.JList<>();
        btnNewCategory = new javax.swing.JButton();
        btnDeleteCategory = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProductDetails = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtCategory = new javax.swing.JTextField();
        txtProductID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtProductName = new javax.swing.JTextField();
        txtQuantity = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        btnNewProduct = new javax.swing.JButton();
        btnSaveProduct = new javax.swing.JButton();
        btnUpdateProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        splitPane.setDividerLocation(300);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Product Category", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        listCategory.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        listCategory.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listCategoryValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listCategory);

        btnNewCategory.setText("New category");
        btnNewCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewCategoryActionPerformed(evt);
            }
        });

        btnDeleteCategory.setText("Delete category");
        btnDeleteCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteCategoryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btnNewCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDeleteCategory, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNewCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeleteCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        splitPane.setLeftComponent(jPanel1);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Product Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        tblProductDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblProductDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProductDetailsMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblProductDetails);

        jLabel1.setText("Category");

        jLabel2.setText("Product ID");

        jLabel3.setText("Product name");

        jLabel4.setText("Quantity");

        jLabel5.setText("Price");

        btnNewProduct.setText("New");
        btnNewProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewProductActionPerformed(evt);
            }
        });

        btnSaveProduct.setText("Save");
        btnSaveProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveProductActionPerformed(evt);
            }
        });

        btnUpdateProduct.setText("Update");
        btnUpdateProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setText("Delete");
        btnDeleteProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteProductActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtQuantity, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 465, Short.MAX_VALUE)
                            .addComponent(txtProductID, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCategory, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtProductName, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPrice)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnNewProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSaveProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUpdateProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDeleteProduct)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtProductID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNewProduct)
                    .addComponent(btnSaveProduct)
                    .addComponent(btnUpdateProduct)
                    .addComponent(btnDeleteProduct))
                .addContainerGap())
        );

        splitPane.setRightComponent(jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPane, javax.swing.GroupLayout.DEFAULT_SIZE, 904, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewCategoryActionPerformed
        NewCategoryDialog dialog = new NewCategoryDialog(this, true);
    }//GEN-LAST:event_btnNewCategoryActionPerformed

    private void btnDeleteCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteCategoryActionPerformed
        int index = this.listCategory.getSelectedIndex();
        if (index < 0) {
            return;
        }

        CategoryDTO dto = this.categories.get(index);
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove " + dto.getName() + "?");
        if (choice == JOptionPane.OK_OPTION) {
            CategoryDAO dao = new CategoryDAO();
            try {
                boolean success = dao.removeCategory(dto.getId());
                if (success) {
                    updateCategoryList();
                    JOptionPane.showMessageDialog(this, dto.getName() + " has been removed...");
                }
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnDeleteCategoryActionPerformed

    private void btnNewProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewProductActionPerformed

        this.creating = !this.creating;

        if (this.creating) {
            this.tblProductDetails.clearSelection();
            this.tblProductDetails.setEnabled(false);
            this.btnNewProduct.setText("Cancel");
            this.btnSaveProduct.setEnabled(true);
            this.btnUpdateProduct.setEnabled(false);
            this.btnDeleteProduct.setEnabled(false);

            this.txtProductID.setEditable(true);
            this.txtProductName.setEditable(true);
            this.txtPrice.setEditable(true);
            this.txtQuantity.setEditable(true);

            this.txtProductID.setText("");
            this.txtProductName.setText("");
            this.txtPrice.setText("");
            this.txtQuantity.setText("");
        } else {
            this.btnNewProduct.setEnabled(true);
            this.btnNewProduct.setText("New");
            this.btnSaveProduct.setEnabled(false);

            this.txtProductID.setEditable(false);
            this.txtProductName.setEditable(false);
            this.txtPrice.setEditable(false);
            this.txtQuantity.setEditable(false);
            this.tblProductDetails.setEnabled(true);
        }
    }//GEN-LAST:event_btnNewProductActionPerformed

    private void btnSaveProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveProductActionPerformed
        if (this.updating) {
            updateProduct();
        }

        if (this.creating) {
            saveNewProduct();
        }


    }//GEN-LAST:event_btnSaveProductActionPerformed

    private void updateProduct() {
        String newProductID = this.txtProductID.getText().trim();
        String newProductName = this.txtProductName.getText().trim();
        String newQuantity = this.txtQuantity.getText().trim();
        String newPrice = this.txtPrice.getText().trim();

        boolean isValid = isValidProductData(newProductID, newProductName, newQuantity, newPrice);

        if (isValid) {
            int selectedRow = this.tblProductDetails.getSelectedRow();
            String oldProductID = (String) this.tblProductDetails.getValueAt(selectedRow, 0);
            ProductDAO dao = new ProductDAO();
            try {
                boolean success = dao.updateProduct(oldProductID, newProductID, newProductName,
                        Integer.parseInt(newQuantity), Float.parseFloat(newPrice));

                if (success) {
                    int productIndex = this.tblProductDetails.getSelectedRow();
                    CategoryDTO category = this.categories.get(this.listCategory.getSelectedIndex());
                    ProductDTO newProduct = new ProductDTO(category, newProductID, newProductName,
                            Integer.parseInt(newQuantity), Float.parseFloat(newPrice));

                    this.model.getData().set(productIndex, newProduct);
                    this.tblProductDetails.updateUI();
                    JOptionPane.showMessageDialog(this, "Product has been updated...");

                    this.btnUpdateProduct.setText("Update");
                    this.btnSaveProduct.setEnabled(false);

                    this.txtProductID.setEditable(false);
                    this.txtProductName.setEditable(false);
                    this.txtPrice.setEditable(false);
                    this.txtQuantity.setEditable(false);
                    this.tblProductDetails.setEnabled(true);
                }
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void saveNewProduct() {
        String productID = this.txtProductID.getText().trim();
        String productName = this.txtProductName.getText().trim();
        String quantity = this.txtQuantity.getText().trim();
        String price = this.txtPrice.getText().trim();

        boolean isValid = isValidProductData(productID, productName, quantity, price);

        if (isValid) {
            int categoryIndex = this.listCategory.getSelectedIndex();
            CategoryDTO category = this.categories.get(categoryIndex);

            ProductDAO dao = new ProductDAO();

            try {
                boolean success = dao.insertNewProduct(productID, category.getId(), productName,
                        Integer.parseInt(quantity), Float.parseFloat(price));

                if (success) {
                    ProductDTO dto = new ProductDTO(category, productID, productName, Integer.parseInt(quantity), Float.parseFloat(price));
                    this.model.getData().add(dto);
                    this.tblProductDetails.updateUI();
                    JOptionPane.showMessageDialog(this, "Add new product successfully!");

                    this.btnNewProduct.setEnabled(true);
                    this.btnNewProduct.setText("New");
                    this.btnSaveProduct.setEnabled(false);

                    this.txtProductID.setEditable(false);
                    this.txtProductName.setEditable(false);
                    this.txtPrice.setEditable(false);
                    this.txtQuantity.setEditable(false);
                    this.tblProductDetails.setEnabled(true);
                }

            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
                Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private void btnUpdateProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateProductActionPerformed
        if (this.listCategory.getSelectedIndex() < 0) {
            return;
        }

        this.updating = !this.updating;

        if (this.updating) {
            this.btnUpdateProduct.setText("Cancel");
            this.btnSaveProduct.setEnabled(true);
            this.btnNewProduct.setEnabled(false);
            this.btnDeleteProduct.setEnabled(false);

            this.txtProductID.setEditable(true);
            this.txtProductName.setEditable(true);
            this.txtPrice.setEditable(true);
            this.txtQuantity.setEditable(true);
            this.tblProductDetails.setEnabled(false);
        } else {
            this.btnUpdateProduct.setText("Update");
            this.btnSaveProduct.setEnabled(false);
            this.btnNewProduct.setEnabled(true);
            this.btnDeleteProduct.setEnabled(true);

            this.txtProductID.setEditable(false);
            this.txtProductName.setEditable(false);
            this.txtPrice.setEditable(false);
            this.txtQuantity.setEditable(false);
            this.tblProductDetails.setEnabled(true);
        }


    }//GEN-LAST:event_btnUpdateProductActionPerformed

    private void btnDeleteProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteProductActionPerformed
        int selectedProductIndex = this.tblProductDetails.getSelectedRow();
        if (selectedProductIndex < 0) {
            return;
        }

        ProductDTO product = this.model.getData().get(selectedProductIndex);
        String productName = product.getName();

        int choice = JOptionPane.showConfirmDialog(this, "Are you sure to remove " + productName + "?");

        if (choice == JOptionPane.CANCEL_OPTION || choice == JOptionPane.NO_OPTION) {
            return;
        }

        ProductDAO dao = new ProductDAO();

        try {
            boolean success = dao.removeProduct(product.getId());

            if (success) {
                this.model.getData().remove(selectedProductIndex);
                if (!this.model.getData().isEmpty()) {
                    this.tblProductDetails.setRowSelectionInterval(0, 0);
                } else {
                    this.btnDeleteProduct.setEnabled(false);
                    this.btnUpdateProduct.setEnabled(false);

                    this.txtProductID.setText("");
                    this.txtProductName.setText("");
                    this.txtQuantity.setText("");
                    this.txtPrice.setText("");

                }
                this.tblProductDetails.updateUI();

                JOptionPane.showMessageDialog(this, productName + " has been removed...");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_btnDeleteProductActionPerformed

    private void listCategoryValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listCategoryValueChanged
        int index = this.listCategory.getSelectedIndex();
        if (index < 0) {
            return;
        }

        this.btnNewProduct.setEnabled(true);
        this.btnNewProduct.setText("New");
        this.btnSaveProduct.setEnabled(false);

        this.txtProductID.setEditable(false);
        this.txtProductName.setEditable(false);
        this.txtPrice.setEditable(false);
        this.txtQuantity.setEditable(false);

        this.tblProductDetails.clearSelection();

        this.btnDeleteCategory.setEnabled(true);

        CategoryDTO categoryDTO = this.categories.get(index);

        this.txtCategory.setText(categoryDTO.getName());

        ProductDAO dao = new ProductDAO();
        try {
            products = dao.getProductsByCategoryID(categoryDTO.getId());

            this.model.getData().clear();

            for (ProductDTO product : products) {
                this.model.getData().add(product);

            }

            this.tblProductDetails.updateUI();

        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            Logger.getLogger(ProductManagement.class.getName()).log(Level.SEVERE, null, ex);
        }

        this.txtProductID.setText("");
        this.txtProductName.setText("");
        this.txtQuantity.setText("");
        this.txtPrice.setText("");

        this.btnUpdateProduct.setEnabled(false);
        this.btnDeleteProduct.setEnabled(false);
    }//GEN-LAST:event_listCategoryValueChanged

    private void tblProductDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProductDetailsMouseClicked
        int selectedRow = this.tblProductDetails.getSelectedRow();

        if (selectedRow < 0) {
            return;
        }

        if (!this.updating) {
            ProductDTO product = this.model.getData().get(selectedRow);

            this.txtCategory.setText(product.getCategory().getName());
            this.txtProductID.setText(product.getId());
            this.txtProductName.setText(product.getName());
            this.txtQuantity.setText(product.getQuantity() + "");
            this.txtPrice.setText(product.getPrice() + "");

            this.btnUpdateProduct.setEnabled(true);
            this.btnDeleteProduct.setEnabled(true);
            this.btnNewProduct.setEnabled(true);
            this.btnNewProduct.setText("New");
            this.btnSaveProduct.setEnabled(false);
        }
    }//GEN-LAST:event_tblProductDetailsMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProductManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProductManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProductManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProductManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductManagement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeleteCategory;
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JButton btnNewCategory;
    private javax.swing.JButton btnNewProduct;
    private javax.swing.JButton btnSaveProduct;
    private javax.swing.JButton btnUpdateProduct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> listCategory;
    private javax.swing.JSplitPane splitPane;
    private javax.swing.JTable tblProductDetails;
    private javax.swing.JTextField txtCategory;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtProductID;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtQuantity;
    // End of variables declaration//GEN-END:variables

}
